@extends('layouts.front')

@section('contents')
<div class="text-center">
    <h1>Hello World</h1>
    <h1>Hello World</h1>
    <h1>Hello World</h1>
</div>
@endsection