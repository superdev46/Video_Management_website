@extends('layouts.dashboard')

@section('contents')
<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Channel Manage area -->
                        
                        <div class="manage-videos-wrap">
                            <h2>Manage My Videos</h2>
                            <hr>
                            <div class="manage-videos-content text-center">
                                No videos found for now!
                            </div>
                        </div>
                        <!-- Ending of Channel Manage area -->
                        </div>
                    </div>
                </div>
            </div>
@endsection