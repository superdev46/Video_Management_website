@extends('layouts.dashboard')

@section('contents')

@endsection